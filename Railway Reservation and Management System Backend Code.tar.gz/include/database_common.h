#pragma once
#include <cstdint>
#include <utility>
#include <string>

#define CHECK_NULLABILITY(stringVar) stringVar, stringVar.size() ? OK_INDICATOR : NULL_INDICATOR 
#define CHECK_NULLABILITY_DOUBLE(doubleVar) doubleVar, doubleVar != 0.0 ? OK_INDICATOR : NULL_INDICATOR

const inline std::string GET_CUSTOMER_UUID_QUERY =
"SELECT ID FROM CustomerContactInformation WHERE Email=:Email;";

const inline std::string GET_EMPLOYEE_UUID_QUERY =
"SELECT ID FROM EmployeeContactInformation WHERE Email=:Email;";

const inline std::string GET_EMPLOYEE_PERMISSIONS_QUERY =
"SELECT Permission, SubPermission FROM EmployeeBasicInformation EI "
"JOIN Department DP ON EI.DepartmentID=DP.DepartmentID "
"WHERE EmployeeID=:ID; ";

const inline std::string GET_EMPLOYEE_MANAGER_UUID_QUERY =
"SELECT ManagerID FROM EmployeeBasicInformation WHERE EmployeeID=:ID";

std::string GetCustomerUUID(const std::string& email);
std::string GetEmployeeUUID(const std::string& email);
std::string GetEmployeeManagerUUID(const std::string& uuid);
std::pair<uint8_t, unsigned long long> GetEmployeePermissions(const std::string& uuid);

